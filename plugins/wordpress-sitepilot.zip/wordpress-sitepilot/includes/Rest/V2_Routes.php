<?php
/**
 * Signed REST transport for the SitePilot Gutenberg v2 lifecycle.
 *
 * @package SitePilot
 */

declare( strict_types = 1 );

namespace SitePilot\Rest;

use SitePilot\Registration\Store;
use SitePilot\Security\Signed_Request_Verifier;
use SitePilot\V2\Acf_Blocks;
use SitePilot\V2\Approval_Proof;
use SitePilot\V2\Block_Usage;
use SitePilot\V2\Commit_Service;
use SitePilot\V2\Editor_Session;
use SitePilot\V2\Feature;
use SitePilot\V2\Media_Service;
use SitePilot\V2\Render_Check;
use SitePilot\Errors\Error_Contract;

/** Registers /wp-json/sitepilot/v2 routes. */
final class V2_Routes {

	public static function register(): void {
		add_action( 'rest_api_init', array( self::class, 'register_routes' ) );
	}

	public static function register_routes(): void {
		self::signed_route( '/editor-sessions', 'editor_sessions', 201 );
		register_rest_route(
			'sitepilot/v2',
			'/editor-bootstrap',
			array(
				'methods'             => 'POST',
				'callback'            => array( self::class, 'editor_bootstrap' ),
				'permission_callback' => '__return_true',
			)
		);
		self::signed_route( '/prepare', 'prepare', 201 );
		self::signed_route( '/commit', 'commit', 200 );
		self::signed_route( '/reconcile', 'reconcile', 200 );
		self::signed_route( '/readback', 'readback', 200 );
		self::signed_route( '/recover', 'recover', 200 );
		self::signed_route( '/conditional-support', 'conditional_support', 200 );
		self::signed_route( '/media-bindings', 'media_bindings', 200 );
		self::signed_route( '/block-definitions', 'block_definitions', 200 );
		self::signed_route( '/block-fixtures', 'block_fixtures', 200 );
		self::signed_route( '/block-usage', 'block_usage', 200 );
		self::signed_route( '/render-check', 'render_check', 200 );
		self::signed_route( '/approval-key', 'approval_key', 200 );
	}

	private static function signed_route( string $route, string $method, int $status ): void {
		register_rest_route(
			'sitepilot/v2',
			$route,
			array(
				'methods'             => 'POST',
				'callback'            => static function ( \WP_REST_Request $request ) use ( $method, $status ) {
					$result = call_user_func( array( self::class, $method ), $request );
					return $result instanceof \WP_Error ? $result : new \WP_REST_Response( $result, $status );
				},
				'permission_callback' => static function ( \WP_REST_Request $request ) use ( $route ) {
					return self::signed_access( $request, 'sitepilot/v2' . $route );
				},
			)
		);
	}

	/** @return array<string, mixed>|\WP_Error */
	public static function editor_sessions( \WP_REST_Request $request ) {
		$params = self::json( $request );
		if ( $params instanceof \WP_Error ) {
			return $params;
		}
		if ( 'sitepilot.editor-session-request/v2' !== ( $params['schemaVersion'] ?? null ) || ! hash_equals( Signed_Request_Verifier::get_authenticated_site_id(), (string) ( $params['siteId'] ?? '' ) ) ) {
			return self::error( 'schema_invalid', 'The editor session request is invalid.', 400 );
		}
		return Editor_Session::mint( $params );
	}

	/** @return array<string, mixed>|\WP_Error */
	public static function editor_bootstrap( \WP_REST_Request $request ) {
		$params = self::json( $request );
		if ( $params instanceof \WP_Error ) {
			return $params;
		}
		$token = isset( $params['bootstrapToken'] ) && is_string( $params['bootstrapToken'] ) ? $params['bootstrapToken'] : '';
		$result = Editor_Session::consume( $token );
		return $result instanceof \WP_Error ? $result : $result;
	}

	/** @return array<string, mixed>|\WP_Error */
	public static function prepare( \WP_REST_Request $request ) {
		$params = self::json( $request );
		return $params instanceof \WP_Error ? $params : Commit_Service::prepare( $params );
	}

	/** @return array<string, mixed>|\WP_Error */
	public static function commit( \WP_REST_Request $request ) {
		$params = self::json( $request );
		return $params instanceof \WP_Error ? $params : Commit_Service::commit( $params );
	}

	/** @return array<string, mixed>|\WP_Error */
	public static function reconcile( \WP_REST_Request $request ) {
		$params = self::json( $request );
		return $params instanceof \WP_Error ? $params : Commit_Service::reconcile( $params );
	}

	/** @return array<string, mixed>|\WP_Error */
	public static function readback( \WP_REST_Request $request ) {
		$params = self::json( $request );
		return $params instanceof \WP_Error ? $params : Commit_Service::readback( $params );
	}

	/** @return array<string, mixed>|\WP_Error */
	public static function recover( \WP_REST_Request $request ) {
		$params = self::json( $request );
		return $params instanceof \WP_Error ? $params : Commit_Service::rollback( $params );
	}

	/** @return array<string, mixed>|\WP_Error */
	public static function conditional_support( \WP_REST_Request $request ) {
		unset( $request );
		return Feature::enabled() ? Commit_Service::conditional_support() : Feature::disabled_error();
	}

	/** @return array<string, mixed>|\WP_Error */
	public static function media_bindings( \WP_REST_Request $request ) {
		$params = self::json( $request );
		return $params instanceof \WP_Error ? $params : Media_Service::bind( $params );
	}

	/**
	 * ACF blocks on this site with their fields and fixture status.
	 *
	 * @return array<string, mixed>|\WP_Error
	 */
	public static function block_definitions( \WP_REST_Request $request ) {
		unset( $request );
		if ( ! Feature::enabled() ) {
			return Feature::disabled_error();
		}
		return array(
			'schemaVersion' => 'sitepilot.block-definitions/v2',
			'acfVersion'    => Acf_Blocks::acf_version(),
			'acfBlocks'     => Acf_Blocks::described_with_status(),
		);
	}

	/**
	 * Records a native save-and-reopen fixture result for one ACF block.
	 *
	 * @return array<string, mixed>|\WP_Error
	 */
	public static function block_fixtures( \WP_REST_Request $request ) {
		if ( ! Feature::enabled() ) {
			return Feature::disabled_error();
		}
		$params = self::json( $request );
		if ( $params instanceof \WP_Error ) {
			return $params;
		}
		if ( 'sitepilot.block-fixture/v2' !== ( $params['schemaVersion'] ?? null ) ) {
			return self::error( 'schema_invalid', 'The block fixture request is invalid.', 400 );
		}
		if ( ! current_user_can( 'edit_pages' ) ) {
			return self::error( 'permission_denied', 'The SitePilot WordPress user cannot create pages, so it cannot run block tests.', 403 );
		}
		return Acf_Blocks::record_fixture( $params );
	}

	/**
	 * Read-only count of third-party blocks in the content this user can edit.
	 *
	 * @return array<string, mixed>|\WP_Error
	 */
	public static function block_usage( \WP_REST_Request $request ) {
		if ( ! Feature::enabled() ) {
			return Feature::disabled_error();
		}
		$params = self::json( $request );
		if ( $params instanceof \WP_Error ) {
			return $params;
		}
		if ( 'sitepilot.block-usage-request/v2' !== ( $params['schemaVersion'] ?? null ) ) {
			return self::error( 'schema_invalid', 'The block usage request is invalid.', 400 );
		}
		if ( ! current_user_can( 'edit_posts' ) ) {
			return self::error( 'permission_denied', 'The SitePilot WordPress user cannot edit posts, so it cannot scan block usage.', 403 );
		}
		return Block_Usage::scan();
	}

	/**
	 * Renders a saved post to check a write didn't break the page.
	 *
	 * @return array<string, mixed>|\WP_Error
	 */
	public static function render_check( \WP_REST_Request $request ) {
		$params = self::json( $request );
		return $params instanceof \WP_Error ? $params : Render_Check::check( $params );
	}

	/**
	 * Registers or replaces the calling client's approval key. Once set, every
	 * v2 write from that client needs a signed approval proof.
	 *
	 * @return array<string, mixed>|\WP_Error
	 */
	public static function approval_key( \WP_REST_Request $request ) {
		$params = self::json( $request );
		return $params instanceof \WP_Error ? $params : Approval_Proof::register_key( $params );
	}

	/** @return bool|\WP_Error */
	private static function signed_access( \WP_REST_Request $request, string $route ) {
		if ( ! Signed_Request_Verifier::verify_rest_request( $request, $route ) ) {
			return Error_Contract::error(
				'sitepilot_v2_',
				'permission_denied',
				__( 'The SitePilot request signature is invalid.', 'sitepilot' ),
				401,
				array(),
				Signed_Request_Verifier::failure_reason() ?? 'signature_invalid'
			);
		}
		$site = Store::get_site( Signed_Request_Verifier::get_authenticated_site_id() );
		$user_id = is_array( $site ) ? (int) ( $site['user_id'] ?? 0 ) : 0;
		$user = $user_id > 0 ? get_user_by( 'id', $user_id ) : false;
		if ( ! $user instanceof \WP_User || ! user_can( $user, 'read' ) ) {
			return Error_Contract::error(
				'sitepilot_v2_',
				'permission_denied',
				__( 'The WordPress user this SitePilot client acts as is missing or can’t read. Register the site again.', 'sitepilot' ),
				403,
				array(),
				'no_mapped_user'
			);
		}
		wp_set_current_user( $user_id );
		return true;
	}

	/** @return array<string, mixed>|\WP_Error */
	private static function json( \WP_REST_Request $request ) {
		$params = $request->get_json_params();
		return is_array( $params ) ? $params : self::error( 'schema_invalid', 'Request body must be a JSON object.', 400 );
	}

	private static function error( string $code, string $message, int $status ): \WP_Error {
		return Error_Contract::error( 'sitepilot_v2_', sanitize_key( $code ), __( $message, 'sitepilot' ), $status );
	}
}
